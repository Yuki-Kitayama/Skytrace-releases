import json, os, unittest
from pathlib import Path
import numpy as np
import shapely
from shapely.geometry import Polygon
from engine import Templates,shape,scene_for,render,triangle,polygons,polygon_plan,maximal_rectangle,gain_rectangle,solve,occlusion_support,palette_masks


class StructureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.templates=Templates(Path(os.environ.get('SKYTRACE_ATLAS','G:/Projects/Skytrace/resources/shapes/Atlas15')))

    def test_affine_triangle_vertices(self):
        points=np.array([[2.,3.],[19.,6.],[7.,21.]])
        s=triangle(points,[0,0,0,255]);m=np.array(s['transform'])
        np.testing.assert_allclose(np.array([[-1,1,1],[1,1,1],[0,-1,1]])@m.T,points)

    def test_cpu_cuda_parity_and_order(self):
        if self.templates.device_maps is None:self.skipTest('CUDA unavailable')
        shapes=[shape(1,[[9,3,14],[2,8,14]],[255,0,0,173]),
                shape(16,[[7,-2,17],[1,9,16]],[0,100,255,201]),
                shape(127,[[10,3,12],[-3,11,13]],[40,30,10,210])]
        s=scene_for(shapes,32,32)
        cpu=render(s,self.templates,gpu=False,samples=3).astype(int)
        gpu=render(s,self.templates,gpu=True,samples=3).astype(int)
        self.assertLess(np.mean(abs(cpu-gpu)),.15)
        self.assertLess(np.mean(np.max(abs(cpu-gpu),2)>2),.01)
        self.assertFalse(np.array_equal(gpu,render(scene_for(shapes[::-1],32,32),self.templates)))

    def test_hole_preserved_by_complete_polygon_plan(self):
        p=Polygon([(2,2),(28,2),(28,28),(2,28)],holes=[[(9,9),(9,21),(21,21),(21,9)]])
        plan=polygon_plan(p,[0,0,0,255],.18)
        im=render(scene_for(plan,32,32),self.templates,samples=4)
        self.assertEqual(int(im[15,15,3]),0)
        self.assertEqual(int(im[5,5,3]),255)
        self.assertEqual(sum(len(q.interiors) for q in polygons(im[:,:,3]/255)),1)

    def test_max_rectangle(self):
        mask=np.zeros((15,20),bool);mask[3:10,5:17]=True
        self.assertEqual(maximal_rectangle(mask),(5,3,12,7))

    def test_stroke_candidate_can_cross_already_covered_ink(self):
        mask=np.zeros((24,24),bool);mask[2:22,10:14]=True;mask[10:14,2:22]=True
        missing=mask.copy();missing[:,10:14]=False
        self.assertEqual(gain_rectangle(mask,missing),(2,10,20,4))

    def test_export_reload_and_real_shear(self):
        a=scene_for([shape(1,[[8,5,16],[0,9,16]],[0,0,0,255])],32,32)
        restored=json.loads(json.dumps(a))
        np.testing.assert_array_equal(render(a,self.templates),render(restored,self.templates))
        m=np.array(a['shapes'][0]['transform'])[:,:2]
        self.assertNotEqual(float(m[:,0]@m[:,1]),0.)

    def test_automatic_budget_and_blank(self):
        im=render(scene_for([shape(1,[[9,4,16],[1,7,16]],[220,0,0,255])],32,32),self.templates)
        result=solve(im,self.templates,cap=4)
        self.assertLessEqual(len(result['shapes']),4)
        actual=render(result,self.templates)
        self.assertLess(np.mean(abs(actual[:,:,3].astype(float)-im[:,:,3])),8.)
        blank=solve(np.zeros((8,8,4),np.uint8),self.templates)
        self.assertEqual(len(blank['shapes']),0)
        with self.assertRaises(ValueError):solve(im,self.templates,cap=301)

    def test_bad_scenes_rejected(self):
        with self.assertRaises(ValueError):render(dict(width=8,height=8,shapes=[]),self.templates)
        with self.assertRaises(ValueError):render(scene_for([shape(1,[[1,1,0],[1,1,0]],[0,0,0,255])],8,8),self.templates)

    def test_occlusion_with_same_color_island_and_transparent_hole(self):
        p=Polygon([(1,1),(30,1),(30,30),(1,30)],holes=[[(7,7),(7,24),(24,24),(24,7)]])
        image=np.zeros((32,32,4),np.uint8);image[1:31,1:31]=[220,0,0,255]
        image[7:25,7:25]=[255,255,255,255];image[13:17,13:17]=[220,0,0,255]
        result=occlusion_support(p,[220,0,0,255],image,{(255,255,255,255)})
        self.assertEqual(len(result.interiors),0)
        image[15,15,3]=0
        result=occlusion_support(p,[220,0,0,255],image,{(255,255,255,255)})
        self.assertEqual(len(result.interiors),1)

    def test_opaque_antialias_does_not_create_blue_fragments(self):
        im=np.full((32,32,4),255,np.uint8)
        im[3:14,3:14,:3]=0;im[3:14,14,:3]=120
        im[20:28,20:28,:3]=[39,80,155]
        regions=palette_masks(im,[255,255,255,255])
        self.assertEqual(len(regions),2)

    def test_opaque_ring_uses_complete_outer_and_inner_program(self):
        original=scene_for([shape(1,[[20,0,19.5],[0,20,19.5]],[255,255,255,255]),
                            shape(16,[[14,0,20],[0,12,20]],[0,0,0,255]),
                            shape(16,[[10,0,20],[0,8,20]],[255,255,255,255])],40,40)
        image=render(original,self.templates,samples=4)
        result=solve(image,self.templates,cap=8)
        self.assertLessEqual(len(result['shapes']),8)
        output=render(result,self.templates,samples=4)
        self.assertGreater(output[20,20,0],240)
        self.assertLess(np.mean(abs(output.astype(float)-image)),12.)

    def test_native_crescent_is_not_discarded_for_worse_optimizer_endpoint(self):
        target=scene_for([shape(136,[[0,-25,36],[8,0,36]],[220,20,10,255])],72,72)
        image=render(target,self.templates,samples=4)
        result=solve(image,self.templates)
        self.assertLessEqual(len(result['shapes']),3)
        actual=render(result,self.templates,samples=4)
        self.assertLess(np.mean(abs(actual.astype(float)-image)),2.)


if __name__=='__main__':unittest.main()
