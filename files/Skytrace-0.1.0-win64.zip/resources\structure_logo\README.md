# Automatic structure logo engine

This is a separate experimental engine, with its own desktop Icon card beside
Simple/Fine. It accepts an image and automatically chooses a scene of at most
300 layers. The cap is a ceiling, not a requested layer count.

## Run

Python 3.10+ with NumPy, Pillow, SciPy, scikit-image, OpenCV, Shapely >=2.1,
Numba and PyTorch. CUDA-enabled PyTorch is used when available. Region analysis
and polygon search run on CPU; full-scene rendering and group replacement
evaluations run on CUDA. The tested local interpreter is
`C:/anaconda3/envs/dachuang/python.exe`.

```
python tools/structure_logo/engine.py input.png result.json --atlas resources/shapes/Atlas15
python tools/structure_logo/engine.py result.json preview.png --atlas resources/shapes/Atlas15 --render-only
python tools/structure_logo/test_engine.py
```

The command writes a scene, a PNG rendered by reloading that scene, and a metrics
JSON. There are no brand names, glyph identities, reference coordinates, or
hand-authored shapes in the algorithm. Optional `--max-layers` is a diagnostic
ceiling and defaults to 300. Infeasible complete candidate sets fail explicitly;
the engine does not silently export a partial image or exceed the cap.

## Algorithm

1. Deterministic color modes and connected contours, retaining subpixel alpha.
   On opaque backgrounds, classify antialias pixels as foreground/background
   mixtures rather than unrelated color fragments.
2. Build complete region programs at several contour tolerances using
   constrained triangulation, exact parallelogram merges, inscribed strokes
   with rotation and shear, and affine fits of native atlas templates. Stroke
   candidates come from the full color support and are ranked by newly covered
   area; previously covered ink is allowed to overlap. Native curved pieces
   may also overlap other pieces inside the same parent support.
   Centroid/covariance registration supplies global affine template seeds.
   Fitting retains the best evaluated pose, including initialization, rather
   than trusting a possibly worse last optimizer iterate.
3. Consider underpainting only for holes verified opaque and covered by a later
   color. Also compete outer-fill/inner-fill programs, including native ellipse
   and arc candidates for both boundaries. Transparent holes cannot be filled
   by a background-color shortcut.
4. Refine small template programs with derivative-free subpixel geometry
   search. Score complete programs using the same four-by-four sampling as
   final export; keep a frontier over layer count, observed topology defects
   and visual error. Preserve long-stroke corners in an additional contour
   simplification family.
5. Solve multiple-choice knapsacks across all regions with three allocations
   balancing absolute error and per-component detail. Compare their actual
   complete renders. Minimize observable topology defects first, then visual
   error, choosing fewer layers for essentially equal scores. If exact local
   topology cannot fit the total budget, retain the least-defective complete
   candidate instead of exporting a partial image or exceeding 300 layers.
6. Try transactional replacements of whole region programs against actual
   full-scene renders. Pair recipient refinements with cheaper donors at a full
   budget. Include edge error and the worst 8x8 tile in selection.
7. Reload the exported scene, supersample the complete layer stack, and report
   PSNR, edge MSE, worst-tile MSE and severe-error pixel count.

The search is bounded and heuristic: it does not prove the globally smallest
possible shape program. The recorded local topology-defect estimate is not an
absolute guarantee of perceptual equivalence after compositing. Final render
inspection remains necessary. Reports include the exact engine source hash.

## Scene contract and integration boundary

`SkytraceAffineLogo1` is **not legacy importable Skytrace JSON**. The legacy
rectangle renderer ignores rotation and its shape parameter structure has no
shear. This engine deliberately uses an explicit versioned schema rather than
silently dropping those transforms. The desktop Icon card opens a separate
generation/preview/save workflow. The game-save exporter is not yet wired to
this schema, and the dialog states that boundary explicitly.

The desktop build deploys the engine to `resources/structure_logo` and the atlas
to `resources/shapes/Atlas15`. Set `SKYTRACE_STRUCTURE_PYTHON`, or place
`structure-logo-runtime.json` beside the executable with a `python` property
pointing to the intended interpreter. No user-specific interpreter path is
committed. `testStructureLogoDialog` exercises the real dialog/process/render
workflow; its optional argument is an artifact directory. Offscreen tests need
the matching Qt offscreen platform plugin and a usable font directory.

Each layer has a game template `type`, an RGBA byte `color`, and a 2x3 affine
`transform`. For normalized template coordinates `(u,v)`, source pixel
coordinates are `transform @ [u,v,1]`. Rectangles use `[-1,1]^2`, ellipses the
unit disk, triangles vertices `(-1,1),(1,1),(0,-1)`. Atlas shapes use native
coordinates divided by `max(abs(native_min),abs(native_max))` independently
on each axis. Nonorthogonal affine columns represent shear. Composition is
linear-light source-over, evaluated at subpixel samples before averaging.

Current candidates support rectangle 1, ellipse 16, triangle 103 and native
atlas templates 136,139,127,109,130,128. Gradient templates and soft ellipse
228 are not included in this flat-color structural search. Candidate support
does not imply that every template is selected on every image; type counts
should be inspected in exported results.

The new renderer gives the algorithm more expressive transforms than the
legacy baseline, so improvements cannot be attributed solely to search.
Do not claim game-export parity until the corresponding transform/export
mapping and desktop preview have been implemented and validated.
