param(
    [Parameter(Mandatory=$true)][string]$InputImage,
    [Parameter(Mandatory=$true)][string]$OutputScene,
    [string]$Python = $env:SKYTRACE_STRUCTURE_PYTHON
)
$ErrorActionPreference = 'Stop'
if (!$Python) { $Python = 'python' }
$project = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$atlas = Join-Path $project 'resources/shapes/Atlas15'
& $Python (Join-Path $PSScriptRoot 'engine.py') $InputImage $OutputScene --atlas $atlas
if ($LASTEXITCODE -ne 0) { throw 'Structure logo generation failed; see the preceding error.' }
