"""Automatic affine-template logo decomposition; no image-specific rules.

Scene v1 is intentionally distinct from legacy Skytrace JSON: its affine
matrix includes shear, which the legacy renderer cannot represent.
"""
from pathlib import Path
import json, math, time
import hashlib, os, uuid
import numpy as np
from PIL import Image
import cv2
from scipy.optimize import minimize
from scipy.ndimage import distance_transform_edt, label
from skimage.measure import find_contours
import shapely
from shapely.geometry import Polygon, LineString, box as polygon_box
from shapely.ops import unary_union
import torch
from numba import njit

SCHEMA = 'SkytraceAffineLogo1'
ENGINE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def linear(x):
    return np.where(x <= .04045, x / 12.92, ((x + .055) / 1.055) ** 2.4)


def srgb(x):
    return np.where(x <= .0031308, x * 12.92, 1.055 * np.maximum(x, 0) ** (1 / 2.4) - .055)


def mixture_coverage(rgb,base,ink):
    base=linear(np.array(base,float)/255);ink=linear(np.array(ink,float)/255)
    rgb=linear(np.asarray(rgb,float)/255);d=ink-base
    t=np.clip(np.sum((rgb-base)*d,axis=-1)/max(float(d@d),1e-9),0,1)
    residual=np.linalg.norm(rgb-(base+t[...,None]*d),axis=-1)
    return t,residual


class Templates:
    def __init__(self, atlas):
        meta = json.loads((Path(atlas) / 'ShapeAlphaAtlas.json').read_text())
        data = np.memmap(Path(atlas) / 'ShapeAlphaAtlas.bin', dtype='<f4', mode='r')
        self.words = [1, 16, 103]
        n = 192
        y, x = np.mgrid[:n, :n].astype(np.float32)
        x = x * 2 / (n - 1) - 1; y = y * 2 / (n - 1) - 1
        self.maps = [np.ones((n, n), np.float32), (x*x+y*y <= 1).astype(np.float32),
                     ((np.abs(x) <= (1+y)/2)).astype(np.float32)]
        for shape in meta['shapes']:
            if shape['candidate_shape_word'] in (213, 211, 214, 221, 222):
                continue  # gradient fills compete separately in a future version
            b = shape['native_bounds']; g = shape['grid_bounds']
            hx = max(abs(b['min_x']), abs(b['max_x']))
            hy = max(abs(b['min_y']), abs(b['max_y']))
            raw = data[shape['layers'][0]['element_offset']:][:g['width']*g['height']].reshape(g['height'], g['width'])
            m = cv2.remap(raw, ((x*hx-g['atlas_min_x'])/g['pitch']).astype(np.float32),
                          ((y*hy-g['atlas_min_y'])/g['pitch']).astype(np.float32),
                          cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
            self.words.append(shape['candidate_shape_word']); self.maps.append(m)
        self.maps = np.ascontiguousarray(self.maps, dtype=np.float32)
        self.centroids=[];self.inverse_covariance_roots=[]
        coordinates=np.stack([x,y],axis=-1).reshape(-1,2).astype(float)
        for slot,m in enumerate(self.maps):
            weights=m.ravel().astype(float);mass=weights.sum();mean=np.sum(coordinates*weights[:,None],axis=0)/mass
            centered=coordinates-mean;cov=(centered.T*weights)@centered/mass
            if slot==0:mean=np.zeros(2);cov=np.eye(2)/3
            elif slot==1:mean=np.zeros(2);cov=np.eye(2)/4
            elif slot==2:mean=np.array([0.,1/3]);cov=np.diag([1/6,2/9])
            eigen,vectors=np.linalg.eigh(cov)
            self.centroids.append(mean);self.inverse_covariance_roots.append((vectors/np.sqrt(np.maximum(eigen,1e-8)))@vectors.T)
        self.device_maps = torch.as_tensor(self.maps,device='cuda') if torch.cuda.is_available() else None


def shape(word, matrix, color):
    return dict(type=int(word), transform=np.asarray(matrix).reshape(2, 3).tolist(), color=list(map(int, color)))


def triangle(p, color):
    # Native triangle vertices (-1,1),(1,1),(0,-1).
    a, b, c = np.asarray(p[:3], float)
    u = (b-a)/2; v = ((a+b)/2-c)/2; center = c+v
    return shape(103, np.column_stack([u, v, center]), color)


def rectangle(poly, color, approximate=False):
    pts = np.asarray(poly.exterior.coords)[:-1]
    if len(pts) != 4:
        if not approximate:return None
        pts=cv2.boxPoints(cv2.minAreaRect(pts.astype(np.float32)))
    center = pts.mean(0)
    # Least-squares parallelogram: includes oblique sides (true shear).
    u = (pts[1]+pts[2]-pts[0]-pts[3])/4
    v = (pts[2]+pts[3]-pts[0]-pts[1])/4
    q = Polygon([center-u-v, center+u-v, center+u+v, center-u+v])
    if q.area < .1:
        return None
    return shape(1, np.column_stack([u, v, center]), color), q


def polygons(mask):
    loops = find_contours(np.pad(mask.astype(float), 1), .5)
    loops = [Polygon(np.fliplr(c)-1) for c in loops if len(c) >= 4]
    result = Polygon()
    for p in sorted(loops, key=lambda q: -q.area):
        if not p.is_valid:
            p = shapely.make_valid(p)
        result = result.symmetric_difference(p)
    if result.is_empty:
        return []
    return [p for p in shapely.get_parts(result) if isinstance(p, Polygon) and p.area > .1]


@njit
def maximal_rectangle(mask):
    heights=np.zeros(mask.shape[1],np.int64)
    best=0;result=(0,0,0,0)
    stack_x=np.empty(mask.shape[1]+1,np.int64);stack_h=np.empty_like(stack_x)
    for y in range(mask.shape[0]):
        size=0
        for x in range(mask.shape[1]):heights[x]=(heights[x]+1) if mask[y,x] else 0
        for x in range(mask.shape[1]+1):
            h=heights[x] if x<mask.shape[1] else 0;start=x
            while size>0 and stack_h[size-1]>h:
                size-=1;start=stack_x[size];hh=stack_h[size]
                area=(x-start)*hh
                if area>best:best=area;result=(start,y-hh+1,x-start,hh)
            if size==0 or stack_h[size-1]<h:
                stack_x[size]=start;stack_h[size]=h;size+=1
    return result


@njit
def gain_rectangle(mask,uncovered):
    """Maximal inscribed rectangle scored by newly covered area; overlap legal."""
    hh,ww=mask.shape
    prefix=np.zeros((hh+1,ww+1),np.int64)
    for y in range(hh):
        row=0
        for x in range(ww):
            row+=int(uncovered[y,x]);prefix[y+1,x+1]=prefix[y,x+1]+row
    heights=np.zeros(ww,np.int64);sx=np.empty(ww+1,np.int64);sh=np.empty(ww+1,np.int64)
    best=-1;bestarea=-1;result=(0,0,0,0)
    for y in range(hh):
        for x in range(ww):heights[x]=heights[x]+1 if mask[y,x] else 0
        size=0
        for x in range(ww+1):
            h=heights[x] if x<ww else 0;start=x
            while size>0 and sh[size-1]>h:
                size-=1;start=sx[size];height=sh[size]
                gain=prefix[y+1,x]-prefix[y-height+1,x]-prefix[y+1,start]+prefix[y-height+1,start]
                area=(x-start)*height
                if gain>best or (gain==best and area>bestarea):
                    best=gain;bestarea=area;result=(start,y-height+1,x-start,height)
            if size==0 or sh[size-1]<h:sx[size]=start;sh[size]=h;size+=1
    return result


def stroke_plan(poly,color,tolerance,programs=False):
    """Whole-stroke cover with rotation AND shear, followed by exact residuals."""
    remaining=poly;strokes=[];prefixes=[];area=poly.area
    points=np.asarray(poly.simplify(.35).exterior.coords)
    edges=np.diff(points,axis=0);lengths=np.linalg.norm(edges,axis=1)
    directions={}
    for v,length in zip(edges,lengths):
        if length<3:continue
        angle=round((np.rad2deg(np.arctan2(v[1],v[0]))%180)*2)/2
        directions[angle]=directions.get(angle,0.)+length
    dominant=sorted(directions,key=lambda a:-directions[a])[:12]
    angles=sorted(set(range(0,180,15))|set(dominant))
    for iteration in range(12):
        best=None
        for angle in angles:
            a=np.deg2rad(angle);co,si=np.cos(a),np.sin(a)
            shears={-.5,0.,.5}
            for b in dominant:
                difference=np.deg2rad(b-angle)
                if abs(np.sin(difference))>.65:
                    shear=np.cos(difference)/np.sin(difference)
                    if abs(shear)<1.4:shears.add(round(shear,3))
            for shear in sorted(shears):
                transform=np.array([[co+shear*si,si-shear*co],[-si,co]])
                pts=np.asarray(shapely.get_coordinates(remaining))@transform.T
                lo=np.floor(pts.min(0))-2;hi=np.ceil(pts.max(0))+2
                ww,hh=np.maximum(4,(hi-lo).astype(int))
                if ww*hh>250000:continue
                yy,xx=np.mgrid[:hh,:ww];inverse=np.linalg.inv(transform)
                u=xx+lo[0];v=yy+lo[1]
                gx=inverse[0,0]*u+inverse[0,1]*v;gy=inverse[1,0]*u+inverse[1,1]*v
                mask=shapely.contains_xy(poly,gx,gy)
                missing=shapely.contains_xy(remaining,gx,gy)
                x,y,w,h=gain_rectangle(np.ascontiguousarray(mask),np.ascontiguousarray(missing))
                if w*h<6:continue
                center=inverse@np.array([x+(w-1)/2+lo[0],y+(h-1)/2+lo[1]])
                for inset in (0.,.3,.7):
                    axes=inverse@np.diag([max(.1,(w-inset)/2),max(.1,(h-inset)/2)])
                    q=Polygon([center-axes[:,0]-axes[:,1],center+axes[:,0]-axes[:,1],center+axes[:,0]+axes[:,1],center-axes[:,0]+axes[:,1]])
                    outside=q.difference(poly).area
                    if outside>max(.12,q.area*.008):continue
                    score=q.intersection(remaining).area
                    if best is None or score>best[0]:best=(score,q,shape(1,np.column_stack([axes,center]),color))
                    break
        if best is None or best[0]<max(5.,area*.018):break
        _,q,s=best;strokes.append(s);remaining=remaining.difference(q)
        if len(strokes)<=8 and remaining.area<area*.3:prefixes.append(strokes[:])
        if remaining.area<area*.05:break
    if not strokes:return []
    bare=strokes[:]
    for p in shapely.get_parts(remaining):
        if isinstance(p,Polygon) and p.area>.05:strokes.extend(polygon_plan(p,color,tolerance))
    return prefixes+[bare,strokes] if programs else strokes


def corner_simplify(poly,tolerance):
    """Preserve long-stroke junctions while simplifying smooth contour arcs."""
    def contour(ring):
        points=np.asarray(Polygon(ring).simplify(.2,preserve_topology=True).exterior.coords)[:-1]
        if len(points)<4:return points
        incoming=points-np.roll(points,1,axis=0);outgoing=np.roll(points,-1,axis=0)-points
        li=np.linalg.norm(incoming,axis=1);lo=np.linalg.norm(outgoing,axis=1)
        cosine=np.sum(incoming*outgoing,axis=1)/np.maximum(li*lo,1e-9)
        protected=np.flatnonzero((li>=2.5)&(lo>=2.5)&(cosine<.8))
        if len(protected)<2:return np.asarray(Polygon(points).simplify(tolerance,preserve_topology=True).exterior.coords)[:-1]
        result=[]
        for a,b in zip(protected,np.roll(protected,-1)):
            indices=np.arange(a,b+1 if b>a else b+len(points)+1)%len(points)
            path=LineString(points[indices]).simplify(tolerance,preserve_topology=False)
            result.extend(list(path.coords)[:-1])
        return result
    result=Polygon(contour(poly.exterior),[contour(r) for r in poly.interiors])
    return result if result.is_valid and not result.is_empty and len(result.interiors)==len(poly.interiors) else poly


def polygon_plan(poly, color, tolerance, merge_tolerance=0.,preserve_corners=False):
    p = corner_simplify(poly,tolerance) if preserve_corners else poly.simplify(tolerance, preserve_topology=True)
    tris = [t for t in shapely.get_parts(shapely.constrained_delaunay_triangles(p)) if t.area>1e-4]
    # Merge complete adjacent triangles, never delete their edge fragments.
    # Exact parallelograms are always eligible; tolerance permits bounded
    # contour simplification but not swallowed holes.
    groups = tris[:]
    while True:
        best = None
        tree=shapely.STRtree(groups)
        for i in range(len(groups)):
            for j in tree.query(groups[i],predicate='intersects'):
                if j>=i:continue
                if not groups[i].intersects(groups[j]):
                    continue
                union = groups[i].union(groups[j])
                if not isinstance(union, Polygon) or len(union.interiors):
                    continue
                r = rectangle(union.simplify(max(.015,merge_tolerance)), color,approximate=merge_tolerance>0)
                if r is None:
                    continue
                s, q = r
                err = union.symmetric_difference(q).area
                allowance=max(min(.08,.002*union.area),merge_tolerance*math.sqrt(union.area)*.65)
                if err <= allowance and (best is None or union.area > best[0]):
                    best = (union.area, i, j, q)
        if best is None:
            break
        _, i, j, q = best
        groups[j] = q; groups.pop(i)
    result = []
    for g in groups:
        r = rectangle(g, color)
        if r is not None:
            result.append(r[0])
        else:
            for tri in shapely.get_parts(shapely.constrained_delaunay_triangles(g)):
                if tri.area<=1e-4:continue
                layer=triangle(list(tri.exterior.coords), color)
                m=np.asarray(layer['transform'],np.float32)
                if abs(m[0,0]*m[1,1]-m[0,1]*m[1,0])<1e-8:continue
                result.append(layer)
    return result



def render_cuda(templates,slots,matrices,colors,w,h,samples):
    device='cuda';yy,xx=torch.meshgrid(torch.arange(h,device=device),torch.arange(w,device=device),indexing='ij')
    total=torch.zeros((h,w,4),device=device)
    mat=torch.as_tensor(matrices,device=device);col=torch.as_tensor(colors,device=device)
    kinds=torch.as_tensor(slots,device=device)
    with torch.no_grad():
        for sy in range(samples):
            for sx in range(samples):
                frame=torch.zeros_like(total)
                for start in range(0,len(slots),24):
                    m=mat[start:start+24];c=col[start:start+24];k=kinds[start:start+24]
                    dx=xx[None]+(sx+.5)/samples-.5-m[:,2,None,None]
                    dy=yy[None]+(sy+.5)/samples-.5-m[:,5,None,None]
                    det=(m[:,0]*m[:,4]-m[:,1]*m[:,3])[:,None,None]
                    if torch.any(det.abs()<1e-9):raise ValueError('Singular affine transform')
                    u=(m[:,4,None,None]*dx-m[:,1,None,None]*dy)/det
                    v=(-m[:,3,None,None]*dx+m[:,0,None,None]*dy)/det
                    inside=(u.abs()<=1)&(v.abs()<=1)
                    cov=torch.nn.functional.grid_sample(templates.device_maps[k,None],torch.stack([u,v],-1),align_corners=True,padding_mode='zeros')[:,0]
                    cov=torch.where((k==0)[:,None,None],inside.float(),cov)
                    cov=torch.where((k==1)[:,None,None],(inside&(u*u+v*v<=1)).float(),cov)
                    cov=torch.where((k==2)[:,None,None],(inside&(u.abs()<=(1+v)*.5)).float(),cov)*inside
                    a=cov*c[:,3,None,None]
                    reverse=torch.cumprod((1-a).flip(0),dim=0).flip(0)
                    tail=torch.cat([reverse[1:],torch.ones_like(reverse[:1])])
                    weights=a*tail
                    premul=torch.einsum('nhw,nc->hwc',weights,c[:,:3])
                    trans=reverse[0]
                    frame[:,:,:3]=frame[:,:,:3]*trans[:,:,None]+premul
                    frame[:,:,3]=frame[:,:,3]*trans+weights.sum(0)
                total+=frame/(samples*samples)
    return total.cpu().numpy()


def render(scene, templates, samples=3, gpu=True):
    if scene.get('schema')!=SCHEMA:raise ValueError('Not an affine-logo scene; legacy JSON must not be silently reinterpreted')
    if not 1<=samples<=8:raise ValueError('Invalid sampling count')
    layers=scene['shapes']; w,h=scene['width'],scene['height']
    if not 1<=w<=4096 or not 1<=h<=4096:raise ValueError('Invalid scene dimensions')
    slots=np.asarray([templates.words.index(s['type']) for s in layers],np.int32)
    matrices=np.asarray([s['transform'] for s in layers],np.float32).reshape(-1,6)
    colors=np.asarray([s['color'] for s in layers],np.float32).reshape(-1,4)/255
    if not np.isfinite(matrices).all() or not np.isfinite(colors).all() or np.any(colors<0) or np.any(colors>1):raise ValueError('Invalid affine/color values')
    if len(matrices) and np.any(abs(matrices[:,0]*matrices[:,4]-matrices[:,1]*matrices[:,3])<1e-9):raise ValueError('Singular affine transform')
    colors[:,:3]=linear(colors[:,:3])
    if gpu and templates.device_maps is not None:
        rgba=render_cuda(templates,slots,matrices,colors,w,h,samples)
    else:
        rgba=np.zeros((h,w,4),np.float32)
        yy,xx=np.mgrid[:h,:w].astype(np.float32)
        for sy in range(samples):
            for sx in range(samples):
                frame=np.zeros_like(rgba)
                for slot,m,c in zip(slots,matrices,colors):
                    det=m[0]*m[4]-m[1]*m[3]
                    if abs(det)<1e-9:continue
                    dx=xx+(sx+.5)/samples-.5-m[2];dy=yy+(sy+.5)/samples-.5-m[5]
                    u=(m[4]*dx-m[1]*dy)/det;v=(-m[3]*dx+m[0]*dy)/det
                    inside=(np.abs(u)<=1)&(np.abs(v)<=1)
                    if slot==0:cov=inside.astype(np.float32)
                    elif slot==1:cov=(inside&(u*u+v*v<=1)).astype(np.float32)
                    elif slot==2:cov=(inside&(np.abs(u)<=(1+v)*.5)).astype(np.float32)
                    else:
                        n=templates.maps.shape[1]
                        cov=cv2.remap(templates.maps[slot],((u+1)*.5*(n-1)).astype(np.float32),((v+1)*.5*(n-1)).astype(np.float32),cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)*inside
                    a=(cov*c[3])[:,:,None]
                    frame[:,:,:3]=frame[:,:,:3]*(1-a)+c[:3]*a
                    frame[:,:,3:]=frame[:,:,3:]*(1-a)+a
                rgba+=frame/(samples*samples)
    rgb=srgb(rgba[:,:,:3]/np.maximum(rgba[:,:,3:],1e-8))
    return np.uint8(np.clip(np.rint(np.concatenate([rgb,rgba[:,:,3:]],2)*255),0,255))


def scene_for(shapes,w,h):
    return dict(schema=SCHEMA,width=w,height=h,shapes=shapes)


def metrics(source, rendered):
    a=source.astype(float)/255;b=rendered.astype(float)/255
    a[:,:,:3]*=a[:,:,3:];b[:,:,:3]*=b[:,:,3:]
    error=np.mean((a-b)**2,axis=2)
    # Compare actual colored edges as well as alpha (opaque logos have no
    # internal alpha boundary). Report foreground-relative error too.
    grad=np.max(np.abs(np.diff(a,axis=0,prepend=a[:1])),2)+np.max(np.abs(np.diff(a,axis=1,prepend=a[:,:1])),2)
    edge=grad>.12
    mismatch=np.max(np.abs(a-b),2)>.25
    return dict(psnr=float(-10*np.log10(max(error.mean(),1e-12))),mse=float(error.mean()),
                edge_mse=float(error[edge].mean()) if edge.any() else 0.,
                severe_pixels=int(mismatch.sum()),worst_tile_mse=float(max(error[y:y+8,x:x+8].mean() for y in range(0,len(error),8) for x in range(0,error.shape[1],8))))


def palette_masks(image,background=None):
    a=image[:,:,3]/255.;valid=a>.02
    pixels=image[:,:,:3][valid].astype(float)
    if not len(pixels):return []
    # Histogram modes, then deterministic color clustering. Antialias pixels
    # are assigned to their nearest fill, rather than treated as new layers.
    quant=(pixels//24).astype(int)
    keys,inv,counts=np.unique(quant,axis=0,return_inverse=True,return_counts=True)
    centers=[]
    for k in np.argsort(-counts):
        c=np.median(pixels[inv==k],axis=0)
        blended=False
        for i,a0 in enumerate(centers):
            for b0 in centers[:i]:
                d=b0-a0;t=np.clip((c-a0)@d/max(d@d,1e-9),0,1)
                if np.linalg.norm(c-(a0+t*d))<24:blended=True
        if not blended and all(np.linalg.norm(c-v)>65 for v in centers):centers.append(c)
        if len(centers)>=8:break
    centers=np.asarray(centers)
    # A JPEG antialias gray is a mixture of black and background, not a blue
    # island merely because gray happens to be nearer blue in RGB distance.
    if background is not None:
        keep=[]
        for i,c in enumerate(centers):
            redundant=False
            for j,a0 in enumerate(centers):
                for k,b0 in enumerate(centers[:j]):
                    if i in (j,k):continue
                    d=b0-a0;t=(c-a0)@d/max(d@d,1e-9)
                    if .06<t<.94 and np.linalg.norm(c-(a0+t*d))<24:redundant=True
            if not redundant:keep.append(c)
        centers=np.asarray(keep)
        bg=np.array(background[:3],float);rgb=image[:,:,:3].astype(float)
        residuals=[];coverages=[]
        for c in centers:
            t,res=mixture_coverage(rgb,bg,c)
            residuals.append(res**2)
            coverages.append(t)
        assignment=np.argmin(residuals,axis=0)
    else:
        assignment=np.argmin(np.sum((image[:,:,:3,None].astype(float)-centers.T[None,None,:,:])**2,axis=2),axis=2)
    result=[]
    for i,c in enumerate(centers):
        if background is not None and np.linalg.norm(c-np.array(background[:3]))<35:continue
        coverage=a.copy() if background is None else coverages[i]
        belongs=assignment==i
        if background is None and i>0:
            # A later ink over an opaque earlier ink has a recoverable alpha.
            # Thresholding its sRGB color as a solid fill makes white lettering
            # much too heavy after linear-light rendering.
            best_res=np.full_like(a,10.)
            for base in centers[:i]:
                t,res=mixture_coverage(image[:,:,:3],base,c)
                use=(a>.98)&(res<.055)&(res<best_res)
                coverage=np.where(use,t,coverage);belongs|=use
                best_res=np.where(use,res,best_res)
        mask=valid&belongs&(coverage>.02)
        if not mask.any():continue
        col=np.median(image[:,:,:3][mask&(coverage>.95)],axis=0) if (mask&(coverage>.95)).any() else c
        # Retain disconnected tiny marks; no area-based dropping of eye dots.
        for p in polygons(mask*coverage):result.append((p,np.uint8(np.rint(col)).tolist()+[255]))
    totals={tuple(c):sum(p.area for p,col in result if col==c) for _,c in result}
    return sorted(result,key=lambda item:(-totals[tuple(item[1])],-item[0].area))


def occlusion_support(poly,color,image,later_colors):
    """Fill only holes proven opaque and covered by a later color program."""
    holes=[]
    for ring in poly.interiors:
        hole=Polygon(ring);x,y,x2,y2=hole.bounds
        xx0=max(0,int(x));yy0=max(0,int(y));xx1=min(image.shape[1],int(x2)+1);yy1=min(image.shape[0],int(y2)+1)
        yy,xx=np.mgrid[yy0:yy1,xx0:xx1];inside=shapely.contains_xy(hole,xx,yy)
        pixels=image[yy0:yy1,xx0:xx1][inside]
        covered=False
        if len(pixels) and np.all(pixels[:,3]>=250):
            for col in later_colors:
                current=np.array(color[:3],float);d=np.array(col[:3],float)-current
                t=np.clip((pixels[:,:3].astype(float)-current)@d/max(d@d,1e-9),0,1)
                residual=np.linalg.norm(pixels[:,:3]-(current+t[:,None]*d),axis=1)
                if np.mean(residual<20)>.995:covered=True
        if not covered:holes.append(list(ring.coords))
    return Polygon(poly.exterior.coords,holes=holes)


def template_plan(poly,color,templates,support=None):
    minx,miny,maxx,maxy=poly.bounds
    w=max(4,int(math.ceil(maxx-minx))+4);h=max(4,int(math.ceil(maxy-miny))+4)
    if w*h>160000:return []
    scale=min(1.,64/max(w,h));ww=max(4,round(w*scale));hh=max(4,round(h*scale))
    yy,xx=np.mgrid[:hh,:ww]
    gx=minx-2+xx/scale;gy=miny-2+yy/scale
    expected=shapely.contains_xy(poly,gx,gy).astype(float)
    allowed=shapely.contains_xy(support,gx,gy) if support is not None else expected>.5
    scoring=(expected>.5)|(~allowed)
    # Every native curved/concave template competes under full affine fits.
    rect=cv2.minAreaRect(np.asarray(poly.exterior.coords,np.float32))
    center=np.asarray(rect[0]);rx=max(.6,rect[1][0]/2);ry=max(.6,rect[1][1]/2)
    best=[]
    # Exact polygon moments, including holes. Affine covariance registration
    # reduces the unknown template pose to a one-angle family and avoids the
    # coupled six-parameter local minima of bounding-box initialization.
    tri_coordinates=[];tri_areas=[]
    for part in shapely.get_parts(shapely.constrained_delaunay_triangles(poly)):
        tri_coordinates.append(np.asarray(part.exterior.coords)[:3]);tri_areas.append(part.area)
    if not tri_coordinates:return []
    vertices=np.asarray(tri_coordinates);areas=np.asarray(tri_areas);mass=areas.sum()
    sums=vertices.sum(1);mean=np.sum(sums/3*areas[:,None],axis=0)/mass
    second=(np.einsum('ni,nj->nij',sums,sums)+np.einsum('nki,nkj->nij',vertices,vertices))/12
    covariance=np.sum(second*areas[:,None,None],axis=0)/mass-np.outer(mean,mean)
    eigen,vectors=np.linalg.eigh(covariance)
    covariance_root=(vectors*np.sqrt(np.maximum(eigen,1e-7)))@vectors.T
    for slot,word in enumerate(templates.words):
        incumbent=[float('inf'),None]
        def objective(z,ret=False):
            cx,cy,lx,ly,angle,shear=z
            sx,sy=np.exp(lx),np.exp(ly);co=np.cos(angle);si=np.sin(angle)
            mat=np.array([[co*sx,(co*shear-si)*sy,cx],[si*sx,(si*shear+co)*sy,cy]])
            inv=np.linalg.inv(mat[:,:2]);u=inv[0,0]*(gx-cx)+inv[0,1]*(gy-cy);v=inv[1,0]*(gx-cx)+inv[1,1]*(gy-cy)
            n=templates.maps.shape[1]
            cov=cv2.remap(templates.maps[slot],((u+1)*.5*(n-1)).astype(np.float32),((v+1)*.5*(n-1)).astype(np.float32),cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
            cov*=((abs(u)<=1)&(abs(v)<=1))
            loss=np.mean((expected-cov)**2*scoring)
            if loss<incumbent[0]:incumbent[:]=[float(loss),shape(word,mat,color)]
            return (loss,shape(word,mat,color)) if ret else loss
        seeds=[]
        for turn in (0,np.pi/2,np.pi,3*np.pi/2):
            seed_rx,seed_ry=(ry,rx) if abs(np.sin(turn))>.5 else (rx,ry)
            z=np.array([*center,np.log(seed_rx),np.log(seed_ry),np.deg2rad(rect[2])+turn,0.])
            seeds.append((objective(z),z))
        moment_seeds=[]
        for degrees in range(0,360,5):
            a=np.deg2rad(degrees);rotation=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
            axes=covariance_root@rotation@templates.inverse_covariance_roots[slot]
            origin=mean-axes@templates.centroids[slot]
            sx=np.linalg.norm(axes[:,0]);theta=np.arctan2(axes[1,0],axes[0,0])
            sy=np.linalg.det(axes)/max(sx,1e-9)
            if sy<.2:continue
            shear=(np.cos(theta)*axes[0,1]+np.sin(theta)*axes[1,1])/sy
            if abs(shear)>4:continue
            z=np.array([*origin,np.log(max(.5,sx)),np.log(max(.5,sy)),theta,shear])
            moment_seeds.append((objective(z),z))
        initial=[min(seeds,key=lambda q:q[0])]+sorted(moment_seeds,key=lambda q:q[0])[:2]
        winner=None
        for _,z in initial:
            bounds=[(minx-w*.5,maxx+w*.5),(miny-h*.5,maxy+h*.5),(np.log(.5),np.log(w*2)),(np.log(.5),np.log(h*2)),(z[4]-.8,z[4]+.8),(-4.,4.)]
            z=np.clip(z,[b[0] for b in bounds],[b[1] for b in bounds])
            fit=minimize(objective,z,method='Powell',bounds=bounds,options=dict(maxiter=12,maxfev=160,xtol=.015,ftol=.002))
            loss,s=objective(fit.x,True)
            if winner is None or loss<winner[0]:winner=(loss,s)
        # Bounded Powell line searches can leave an excellent initial pose for
        # a worse point on a non-unimodal silhouette. Keep the best actual
        # evaluation, including all initial/covariance seeds, not just fit.x.
        if incumbent[0]<.065:best.append([incumbent[1]])
    return best


def partition_plans(poly,color,templates):
    """Compete complete programs of curved substructures, not single pixels.

    Spatial cuts are candidate construction only: exported templates are never
    clipped to a region. Their complete footprint is scored after assembly.
    """
    x,y,x2,y2=poly.bounds;results=[]
    cut_groups=[]
    for vertical in (True,False):
        middle=(x+x2)/2 if vertical else (y+y2)/2
        cutters=([polygon_box(x-1,y-1,middle,y2+1),polygon_box(middle,y-1,x2+1,y2+1)] if vertical else
                 [polygon_box(x-1,y-1,x2+1,middle),polygon_box(x-1,middle,x2+1,y2+1)])
        cut_groups.append(cutters)
    if len(poly.interiors)>0:
        mx=(x+x2)/2;my=(y+y2)/2
        cut_groups.append([polygon_box(x-1,y-1,mx,my),polygon_box(mx,y-1,x2+1,my),polygon_box(x-1,my,mx,y2+1),polygon_box(mx,my,x2+1,y2+1)])
    for cutters in cut_groups:
        pieces=[p for cutter in cutters for p in shapely.get_parts(poly.intersection(cutter)) if isinstance(p,Polygon) and p.area>.5]
        frontiers=[]
        for piece in pieces:
            options=[polygon_plan(piece,color,.35),polygon_plan(piece,color,1.)]
            options+=template_plan(piece.simplify(.25),color,templates,support=poly)
            a,b,c,d=piece.bounds;ox=int(a)-2;oy=int(b)-2;ww=max(4,int(c)-ox+3);hh=max(4,int(d)-oy+3)
            yy,xx=np.mgrid[:hh,:ww];expected=shapely.contains_xy(piece,xx+ox,yy+oy).astype(float)
            allowed=shapely.contains_xy(poly,xx+ox,yy+oy)
            scored=[]
            for plan in options:
                if not plan:continue
                local=[]
                for s in plan:
                    q=dict(s);m=np.array(s['transform']);m[:,2]-=[ox,oy];q['transform']=m.tolist();local.append(q)
                alpha=render(scene_for(local,ww,hh),templates,samples=2,gpu=False)[:,:,3]/255
                loss=float(np.sum((alpha-expected)**2*((expected>.5)|(~allowed))))
                scored.append((loss,plan))
            frontiers.append(scored)
        for price in (.05,.25,1.,4.):
            plan=[]
            for options in frontiers:
                if options:plan.extend(min(options,key=lambda q:q[0]+price*len(q[1]))[1])
            if plan:results.append(plan)
    return results


def csg_plans(poly,color,image,templates):
    """Outer fill + colored inner shapes, with same-ink islands restored later.

    Only fully opaque, two-ink holes qualify. No transparent erasing exists.
    """
    retained=[];holes=[];fill_reference=None
    for ring in poly.interiors:
        p=Polygon(ring);x,y,x2,y2=p.bounds
        x=max(0,int(x));y=max(0,int(y));x2=min(image.shape[1],int(x2)+1);y2=min(image.shape[0],int(y2)+1)
        yy,xx=np.mgrid[y:y2,x:x2];pixels=image[y:y2,x:x2][shapely.contains_xy(p,xx,yy)]
        if not len(pixels) or np.any(pixels[:,3]<250):retained.append(list(ring.coords));continue
        fill=np.median(pixels[:,:3],axis=0).astype(int).tolist()+[255]
        t,res=mixture_coverage(pixels[:,:3],color[:3],fill[:3])
        if np.linalg.norm(np.array(fill[:3])-np.array(color[:3]))<50 or np.mean(res<.09)<.99 or np.sum(t<.1)>poly.area:
            retained.append(list(ring.coords));continue
        if fill_reference is not None and np.linalg.norm(np.array(fill[:3])-np.array(fill_reference[:3]))>25:
            retained.append(list(ring.coords));continue
        if fill_reference is None:fill_reference=fill
        fill=fill_reference
        options=[polygon_plan(p,fill,.35),polygon_plan(p,fill,1.)]+template_plan(p.simplify(.25),fill,templates)
        scored=[]
        yy,xx=np.mgrid[y:y2,x:x2];expected=shapely.contains_xy(p,xx,yy).astype(float)
        for plan in options:
            if not plan:continue
            local=[]
            for s in plan:
                q=dict(s);m=np.array(s['transform']);m[:,2]-=[x,y];q['transform']=m.tolist();local.append(q)
            alpha=render(scene_for(local,x2-x,y2-y),templates,samples=2,gpu=False)[:,:,3]/255
            scored.append((float(np.sum((alpha-expected)**2)),plan))
        holes.append(scored)
    if not holes:return []
    outer=Polygon(poly.exterior.coords,retained);results=[]
    outside_options=[polygon_plan(outer,color,eps,merge_tolerance=.4) for eps in (.35,.6,1.,1.6)]
    outside_options+=template_plan(outer.simplify(.25),color,templates)
    for outside in outside_options:
        for price in (.1,1.):
            plan=outside[:]
            for options in holes:
                if options:plan+=min(options,key=lambda q:q[0]+price*len(q[1]))[1]
            results.append(plan)
    return results


def refine_small_program(plan,color,expected,weights,x,y,templates):
    """Derivative-free subpixel fitting of a complete small shape program."""
    h,w=expected.shape;local=[]
    for s in plan:
        q=dict(s);m=np.array(s['transform']);m[:,2]-=[x,y];q['transform']=m.tolist();local.append(q)
    different=[s['color'] for s in plan if s['color']!=color]
    def loss(layers):
        frame=render(scene_for(layers,w,h),templates,samples=4,gpu=False)
        alpha=frame[:,:,3]/255
        if different:alpha*=mixture_coverage(frame[:,:,:3],different[0][:3],color[:3])[0]
        return float(np.sum((alpha-expected)**2*weights))
    best=loss(local)
    for step in (.25,.1,.04):
        for layer in range(len(local)):
            for parameter in range(6):
                original=np.asarray(local[layer]['transform']);winner=original;value=best
                for sign in (-1,1):
                    m=original.copy();delta=sign*step
                    if parameter<2:m[parameter,2]+=delta
                    elif parameter<4:
                        k=parameter-2;m[:,k]*=1+delta/max(np.linalg.norm(m[:,k]),.5)
                    elif parameter==4:
                        a=np.deg2rad(delta);rotation=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
                        m[:,:2]=rotation@m[:,:2]
                    else:m[:,1]+=m[:,0]*delta/max(np.linalg.norm(m[:,0]),.5)
                    if abs(np.linalg.det(m[:,:2]))<1e-6:continue
                    check=m.astype(np.float32)
                    if abs(check[0,0]*check[1,1]-check[0,1]*check[1,0])<1e-8:continue
                    trial=[dict(s) for s in local];trial[layer]['transform']=m.tolist()
                    error=loss(trial)
                    if error<value-1e-8:value=error;winner=m
                local[layer]['transform']=winner.tolist();best=value
    result=[]
    for s in local:
        q=dict(s);m=np.asarray(s['transform']);m[:,2]+=[x,y];q['transform']=m.tolist();result.append(q)
    return result


def solve(image,templates,cap=300,progress=None,quick=False,hybrid=False):
    if not 1<=cap<=300:raise ValueError('layer cap must be within 1..300')
    h,w=image.shape[:2];fixed=[];background=None
    if np.all(image[:,:,3]==255):
        border=np.concatenate([image[0],image[-1],image[:,0],image[:,-1]])
        bg=np.median(border,axis=0)
        if np.mean(np.max(abs(border.astype(float)-bg),axis=1)<8)>.95:
            background=bg.astype(int).tolist()
            fixed=[shape(1,[[w/2,0,(w-1)/2],[0,h/2,(h-1)/2]],background)]
    regions=palette_masks(image,background)
    base_color=regions[0][1][:3] if regions else [0,0,0]
    choices=[];region_areas=[]
    started=time.time()
    for index,(poly,col) in enumerate(regions):
        if progress:progress(dict(stage="region_start",region=index+1,total=len(regions)))
        later_colors={tuple(c) for _,c in regions[index+1:] if c!=col}
        original_poly=poly
        poly=occlusion_support(poly,col,image,later_colors)
        options=[]
        for eps in (.18,.35,.6,1.,1.6,2.5,4.,6.):
            plan=polygon_plan(poly,col,eps)
            if plan:options.append(plan)
        for eps in (.18,.6,1.6):
            plan=polygon_plan(poly,col,eps,merge_tolerance=.55)
            if plan:options.append(plan)
        for eps in (.6,1.,2.,4.):
            plan=polygon_plan(poly,col,eps,merge_tolerance=.4,preserve_corners=True)
            if plan:options.append(plan)
        if not quick and poly.area>=6 and len(poly.exterior.coords)<600:
            options.extend(template_plan(poly,col,templates))
        if not quick and poly.area>=120 and (len(poly.interiors)>0 or len(poly.exterior.coords)>80):
            options.extend(partition_plans(poly,col,templates))
        if (not quick or hybrid) and len(poly.interiors)>0:
            options.extend(csg_plans(poly,col,image,templates))
        if (not quick or hybrid) and poly.area>=35:
            options.extend(stroke_plan(poly,col,.6,programs=True))
        # Region candidates are rendered and scored in their complete local
        # context. Holes and thin strokes carry explicit penalties.
        minx,miny,maxx,maxy=poly.bounds
        x=max(0,int(minx)-3);y=max(0,int(miny)-3);x2=min(w,int(maxx)+4);y2=min(h,int(maxy)+4)
        yy,xx=np.mgrid[y:y2,x:x2]
        binary_target=shapely.contains_xy(poly,xx,yy)
        visible_target=shapely.contains_xy(original_poly,xx,yy)
        hidden=binary_target&~visible_target
        near=distance_transform_edt(~binary_target)<=1.25
        same=np.linalg.norm(image[y:y2,x:x2,:3].astype(float)-np.array(col[:3]),axis=2)<75
        expected=image[y:y2,x:x2,3]/255.*near*same
        if background is not None:
            expected=mixture_coverage(image[y:y2,x:x2,:3],background[:3],col[:3])[0]*near
        elif col[:3]!=base_color:
            t,res=mixture_coverage(image[y:y2,x:x2,:3],base_color,col[:3])
            use=(image[y:y2,x:x2,3]>250)&(res<.055)&near
            expected=np.where(use,t,expected)
        elif len(poly.interiors)<len(original_poly.interiors):
            expected=np.maximum(expected,binary_target.astype(float))
        edge=distance_transform_edt(binary_target)<=1.5
        scored=[]
        for plan in options:
            local=[]
            for s in plan:
                q=dict(s);mat=np.array(s['transform']);mat[:,2]-=[x,y];q['transform']=mat.tolist();local.append(q)
            frame=render(scene_for(local,x2-x,y2-y),templates,samples=4,gpu=len(local)*(x2-x)*(y2-y)>50000)
            alpha=frame[:,:,3]/255
            different=[s['color'] for s in plan if s['color']!=col]
            if different:
                alpha=mixture_coverage(frame[:,:,:3],different[0][:3],col[:3])[0]*alpha
            delta=(alpha-expected)**2
            binary=(alpha>=.5)|hidden
            comps=label(binary)[1];targetcomps=label((expected>=.5)|hidden)[1]
            _,hier=cv2.findContours(binary.astype(np.uint8),cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
            actualholes=0 if hier is None else int(np.sum(hier[0,:,3]>=0))
            _,target_hierarchy=cv2.findContours(((expected>=.5)|hidden).astype(np.uint8),cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
            targetholes=0 if target_hierarchy is None else int(np.sum(target_hierarchy[0,:,3]>=0))
            topo=abs(comps-targetcomps)+abs(actualholes-targetholes)
            loss=float((delta*(1+3*edge)*(~hidden)).sum()+topo*max(5.,original_poly.area*.08))
            # Balance structure errors across components. Otherwise one large
            # underpaint monopolizes the budget while small lettering/eyes
            # lose their characteristic details.
            loss/=max(2.,math.sqrt(original_poly.area))
            scored.append(dict(layers=plan,loss=loss,topology_error=int(topo)))
        small=sorted([q for q in scored if len(q['layers'])<=4 and any(s['type']!=103 for s in q['layers'])],key=lambda q:q['loss'])[:3]
        for q in small:
            refined=refine_small_program(q['layers'],col,expected,(1+3*edge)*(~hidden),x,y,templates)
            local=[]
            for s in refined:
                v=dict(s);m=np.array(s['transform']);m[:,2]-=[x,y];v['transform']=m.tolist();local.append(v)
            frame=render(scene_for(local,x2-x,y2-y),templates,samples=4,gpu=len(local)*(x2-x)*(y2-y)>50000);alpha=frame[:,:,3]/255
            different=[s['color'] for s in refined if s['color']!=col]
            if different:alpha*=mixture_coverage(frame[:,:,:3],different[0][:3],col[:3])[0]
            binary=(alpha>=.5)|hidden
            _,hier=cv2.findContours(binary.astype(np.uint8),cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
            holes=0 if hier is None else int(np.sum(hier[0,:,3]>=0))
            topo=abs(label(binary)[1]-label((expected>=.5)|hidden)[1])+abs(holes-targetholes)
            value=float((((alpha-expected)**2)*(1+3*edge)*(~hidden)).sum()+topo*max(5.,original_poly.area*.08))/max(2.,math.sqrt(original_poly.area))
            scored.append(dict(layers=refined,loss=value,topology_error=int(topo)))
        # Do not trade a recoverable eye highlight, letter counter or connected
        # stroke for a small average error improvement. Preserve raster-observed
        # topology whenever this region has a feasible matching program.
        # Keep the Pareto frontier, including low-count whole-template plans.
        frontier=[]
        for q in sorted(scored,key=lambda q:(len(q['layers']),q['topology_error'],q['loss'])):
            if not any(len(p['layers'])<=len(q['layers']) and p['topology_error']<=q['topology_error'] and p['loss']<=q['loss']+1e-8 for p in frontier):frontier.append(q)
        if not frontier:continue
        choices.append(frontier)
        region_areas.append(original_poly.area)
        if progress:
            event=dict(region=index+1,total=len(regions),alternatives=len(frontier),seconds=round(time.time()-started,2))
            if index==0 or (index+1)%5==0:
                draft=fixed+[layer for options in choices for layer in min(options,key=lambda p:len(p["layers"]))["layers"]]
                event["draft"]=scene_for(draft[:cap],w,h)
            progress(event)
    # Multiple-choice knapsack: globally optimal among complete region plans,
    # not a greedy assignment of the remaining layer budget.
    if progress:progress(dict(stage="select_and_render",region=len(regions),total=len(regions)))
    def compose(selection):return fixed+[s for opts,i in zip(choices,selection) for s in opts[i]['layers']]
    def objective(layers):
        frame=render(scene_for(layers,w,h),templates,samples=4)
        m=metrics(image,frame)
        return m['mse']+.6*m['edge_mse']+.15*m['worst_tile_mse']
    complete=[]
    for exponent in (0.,.5,-.5):
        dp={len(fixed):((0,0.),[])}
        for options,area in zip(choices,region_areas):
            nxt={}
            for used,(loss,path) in dp.items():
                for i,q in enumerate(options):
                    n=used+len(q['layers'])
                    if n>cap:continue
                    value=(loss[0]+q['topology_error'],loss[1]+q['loss']*max(2.,math.sqrt(area))**(2*exponent))
                    if n not in nxt or value<nxt[n][0]:nxt[n]=(value,path+[i])
            if not nxt:raise RuntimeError('The complete structure candidates exceed the layer cap; no partial image is exported')
            dp=nxt
        bestloss=min(v[0] for v in dp.values())
        count=min(n for n,v in dp.items() if v[0][0]==bestloss[0] and v[0][1]<=bestloss[1]+1e-5)
        selection=dp[count][1];program=compose(selection)
        complete.append((bestloss[0],objective(program),len(program),selection))
    _,score,_,selected=min(complete,key=lambda q:(q[0],q[1],q[2]))
    layers=compose(selected);replacements=0;paired_replacements=0
    # Retry only when the inexpensive complete fit visibly misses the target.
    # Retain that fit if the added search fails to improve the full render.
    if quick and not hybrid and score > .045:
        if progress:progress(dict(stage="detail_retry",region=1,total=len(regions),draft=scene_for(layers,w,h)))
        try:
            def retry_progress(event):
                event.pop("draft",None)
                event["pass"]="detail"
                progress(event)
            retry=solve(image,templates,cap,retry_progress if progress else None,quick=True,hybrid=True)
        except RuntimeError:
            retry=None
        if retry is not None and retry["search"]["selected_loss"] < score:
            retry["search"]["seconds"]=time.time()-started
            retry["search"]["detail_retry"]=True
            return retry
    # Actual complete-scene group replacement, with the same alpha/linear
    # compositing as the export renderer. A trial is transactional: no partial
    # deletion or refinement is committed when its complete render is worse.
    for sweep in range(1 if hybrid else 2):
        changed=False
        for region,options in enumerate(choices):
            old=selected[region];best=old;bestscore=score;bestcount=len(layers)
            for i,option in enumerate(options):
                if i==old:continue
                if option['topology_error']>options[old]['topology_error']:continue
                candidate=selected[:];candidate[region]=i
                trial=compose(candidate)
                if len(trial)>cap:continue
                q=objective(trial)
                if q<bestscore-1e-7 or (q<=bestscore+1e-7 and len(trial)<bestcount):
                    best=i;bestscore=q;bestcount=len(trial)
            if best!=old:
                selected[region]=best;score=bestscore;layers=compose(selected)
                replacements+=1;changed=True
        if not changed:break
    # At a full budget, one-at-a-time replacements cannot improve a recipient
    # that needs more layers. Pair it transactionally with a cheaper donor.
    for sweep in range(1 if hybrid else 2):
        pairs=[]
        for r,options in enumerate(choices):
            current=options[selected[r]]
            for i,q in enumerate(options):
                extra=len(q['layers'])-len(current['layers'])
                if extra<=0 or q['loss']>=current['loss']:continue
                for d,donors in enumerate(choices):
                    if d==r:continue
                    old=donors[selected[d]]
                    for j,cheap in enumerate(donors):
                        if q['topology_error']+cheap['topology_error']>current['topology_error']+old['topology_error']:continue
                        saved=len(old['layers'])-len(cheap['layers'])
                        if saved<extra-(cap-len(layers)):continue
                        delta=q['loss']-current['loss']+cheap['loss']-old['loss']
                        pairs.append((delta,r,i,d,j))
        best=None
        for _,r,i,d,j in sorted(pairs)[:12 if hybrid else 40]:
            candidate=selected[:];candidate[r]=i;candidate[d]=j
            trial=compose(candidate)
            if len(trial)>cap:continue
            value=objective(trial)
            if value<score-1e-7 and (best is None or value<best[0]):best=(value,candidate,trial)
        if best is None:break
        score,selected,layers=best;paired_replacements+=1
    scene=scene_for(layers,w,h)
    scene['search']=dict(regions=len(choices),candidate_plans=sum(map(len,choices)),selected_loss=score,topology_defects=sum(q[i]['topology_error'] for q,i in zip(choices,selected)),group_replacements=replacements,paired_replacements=paired_replacements,cap=cap,seconds=time.time()-started,backend='CUDA' if templates.device_maps is not None else 'CPU')
    return scene


def main():
    import argparse
    p=argparse.ArgumentParser(description='Experimental automatic affine logo structure engine')
    p.add_argument('input',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--atlas',type=Path,required=True);p.add_argument('--max-layers',type=int,default=300)
    p.add_argument('--render-only',action='store_true')
    p.add_argument('--hybrid',action='store_true')
    p.add_argument('--deep',dest='quick',action='store_false',help='Enable expensive affine template searches')
    p.add_argument('--max-side',type=int,default=384,help='Maximum input side in pixels; 0 preserves full size')
    args=p.parse_args()
    if args.input.resolve()==args.output.resolve():p.error('Output must not overwrite the input image/scene')
    templates=Templates(args.atlas)
    if args.render_only:
        scene=json.loads(args.input.read_text());assert scene['schema']==SCHEMA
        Image.fromarray(render(scene,templates)).save(args.output);return
    from PIL import ImageOps
    image=ImageOps.exif_transpose(Image.open(args.input)).convert("RGBA")
    source_size=image.size
    if args.max_side>0:image.thumbnail((args.max_side,args.max_side),Image.Resampling.LANCZOS)
    working_size=image.size
    image=np.asarray(image)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with Path(str(args.output)+".log").open("w",encoding="utf-8",buffering=1) as log:
        def progress(event):
            draft=event.pop("draft",None)
            if draft is not None:
                preview=Path(str(args.output)+".draft.png")
                pending=preview.with_suffix(".tmp")
                Image.fromarray(render(draft,templates,samples=2)).save(pending,format="PNG")
                os.replace(pending,preview)
                event["preview"]=str(preview.resolve())
            line=json.dumps(event)
            print(line,flush=True)
            log.write(line+"\n")
        progress(dict(stage="analyze",source_size=source_size,working_size=working_size,
                      backend="CUDA" if templates.device_maps is not None else "CPU"))
        try:
            scene=solve(image,templates,args.max_layers,progress,quick=args.quick,hybrid=args.hybrid)
        except Exception:
            import traceback
            traceback.print_exc(file=log)
            raise
        progress(dict(stage="export",layers=len(scene["shapes"])))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    scene['engine_sha256']=ENGINE_SHA256
    payload=json.dumps(scene,indent=2)
    # Round-trip the exact export payload; no hidden fitted parameters in preview.
    restored=json.loads(payload)
    actual=render(restored,templates,samples=4)
    report=dict(source_size=source_size,working_size=working_size,layers=len(scene['shapes']),**metrics(image,actual),**scene['search'],engine_sha256=scene['engine_sha256'])
    token=uuid.uuid4().hex
    tmp=Path(str(args.output)+'.'+token+'.tmp')
    tmp_image=Path(str(tmp)+'.png');tmp_metrics=Path(str(tmp)+'.metrics.json')
    try:
        tmp.write_text(payload);Image.fromarray(actual).save(tmp_image,format='PNG')
        tmp_metrics.write_text(json.dumps(report,indent=2))
        os.replace(tmp_image,str(args.output)+'.png');os.replace(tmp_metrics,str(args.output)+'.metrics.json');os.replace(tmp,args.output)
    finally:
        for q in (tmp,tmp_image,tmp_metrics):
            if q.exists():q.unlink()
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
