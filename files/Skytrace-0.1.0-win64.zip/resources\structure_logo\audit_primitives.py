"""Unseen affine-pose recovery audit for every flat game template."""
from pathlib import Path
import argparse,json
import numpy as np
from PIL import Image
from engine import Templates,shape,scene_for,render,solve,metrics,ENGINE_SHA256


def main():
    p=argparse.ArgumentParser();p.add_argument('--atlas',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    templates=Templates(a.atlas);rows=[]
    angle=np.deg2rad(23)
    axes=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])@np.array([[18.,5.],[0.,24.]])
    for word in templates.words:
        reference=scene_for([shape(word,np.column_stack([axes,[36.,36.]]),[30,80,210,255])],72,72)
        image=render(reference,templates,samples=4)
        # The solver receives pixels and the complete catalog, never the word,
        # original transform or reference scene used to construct the test.
        result=solve(image,templates);result['engine_sha256']=ENGINE_SHA256
        payload=json.dumps(result,indent=2);restored=json.loads(payload)
        actual=render(restored,templates,samples=4)
        Image.fromarray(image).save(a.output/f'{word}-source.png')
        Image.fromarray(actual).save(a.output/f'{word}-result.png')
        (a.output/f'{word}.json').write_text(payload)
        row=dict(template=word,layers=len(result['shapes']),types=[s['type'] for s in result['shapes']],engine_sha256=ENGINE_SHA256,**metrics(image,actual))
        rows.append(row);print(json.dumps(row),flush=True)
    (a.output/'metrics.json').write_text(json.dumps(rows,indent=2))


if __name__=='__main__':main()
