"""Build side-by-side evidence from exported scenes and their actual renders."""
from pathlib import Path
import argparse,json,zipfile
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from engine import metrics


def main():
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True)
    p.add_argument('--inputs',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    names=['puma','mobil1','japanese','english','chinese','goodyear','yokohama','tagheuer','goodsmile','michelin']
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
    rows=[];files=[];hashes=set()
    for page in range(4):
        group=names[page*3:page*3+3]
        if not group:continue
        sheet=Image.new('RGB',(1080,len(group)*300),'white');draw=ImageDraw.Draw(sheet)
        for row,name in enumerate(group):
            source=a.inputs/(name+'.png');old=a.baseline/(name+'-auto.json');new=a.results/(name+'.json')
            scene=json.loads(new.read_text());assert scene['schema']=='SkytraceAffineLogo1';assert len(scene['shapes'])<=300
            hashes.add(scene['engine_sha256'])
            inputs=[Image.open(source).convert('RGBA'),Image.open(str(old)+'.png').convert('RGBA'),Image.open(str(new)+'.png').convert('RGBA')]
            oldmetrics=metrics(np.asarray(inputs[0]),np.asarray(inputs[1]));newmetrics=metrics(np.asarray(inputs[0]),np.asarray(inputs[2]))
            report=json.loads(Path(str(new)+'.metrics.json').read_text());assert abs(report['psnr']-newmetrics['psnr'])<1e-8
            oldcount=len(json.loads(old.read_text())['shapes']);newcount=len(scene['shapes'])
            labels=[name+' / source',f'Previous {oldcount} layers / {oldmetrics["psnr"]:.2f} dB',f'Structure {newcount} layers / {newmetrics["psnr"]:.2f} dB']
            x=np.asarray(inputs[0],float)/255;y=np.asarray(inputs[2],float)/255;x[:,:,:3]*=x[:,:,3:];y[:,:,:3]*=y[:,:,3:]
            err=np.mean((x-y)**2,2)
            tiles=[(err[yy:yy+16,xx:xx+16].mean(),xx,yy) for yy in range(0,err.shape[0],8) for xx in range(0,err.shape[1],8)]
            _,cx,cy=max(tiles);cx=max(0,min(cx-16,err.shape[1]-64));cy=max(0,min(cy-12,err.shape[0]-48))
            box=(cx,cy,min(err.shape[1],cx+64),min(err.shape[0],cy+48))
            for col,(im,label) in enumerate(zip(inputs,labels)):
                ox=col*360;oy=row*300;draw.text((ox+8,oy+5),label,font=font,fill='black')
                thumb=im.copy();thumb.thumbnail((344,130),Image.Resampling.LANCZOS)
                sheet.paste(thumb,(ox+8,oy+30),thumb)
                crop=im.crop(box);crop.thumbnail((320,130))
                scale=min(320/crop.width,130/crop.height);crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.NEAREST)
                sheet.paste(crop,(ox+8,oy+164),crop)
            rows.append(dict(sample=name,old_layers=oldcount,old=oldmetrics,new_layers=newcount,new=newmetrics,search=scene['search'],crop=list(box)))
            for q in (source,old,Path(str(old)+'.png'),new,Path(str(new)+'.png'),Path(str(new)+'.metrics.json')):files.append((q,name+'/'+('previous-' if q==old or q==Path(str(old)+'.png') else '')+q.name))
        sheet.save(a.output/f'comparison-{page+1}.png')
    assert len(hashes)==1,'All final samples must come from one frozen engine version'
    (a.output/'metrics.json').write_text(json.dumps(rows,indent=2))
    with zipfile.ZipFile(a.output/'all-scenes-and-renders.zip','w',zipfile.ZIP_DEFLATED) as z:
        for q,name in files:z.write(q,name)
        for q in a.output.glob('comparison-*.png'):z.write(q,q.name)
        z.write(a.output/'metrics.json','metrics.json')
    with zipfile.ZipFile(a.output/'all-scenes-and-renders.zip') as z:assert z.testzip() is None
    print(json.dumps([dict(sample=r['sample'],layers=r['new_layers'],psnr=round(r['new']['psnr'],3)) for r in rows]))


if __name__=='__main__':main()
